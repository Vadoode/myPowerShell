﻿Configuration ITSwitchDC {

 param ( 
        $CountryName, $PsgrName
    )

    # this module contains the resources we're using.
    Import-DscResource -ModuleName PsDesiredStateConfiguration

   
   

     @('AD-Domain-Services', 'DNS', 'GPMC', 'RSAT-AD-Tools', 'RSAT-DNS-Server').ForEach({
             WindowsFeature $_
             {
                Name = $_
                Ensure = 'Present'
            }
         } 
      )
   

    File TestFile
    {
        Ensure = "Present"
        DestinationPath = "C:\TestFile"
        Contents = "Hello there $PsgrName! Welcome to $CountryName!"
    }
}



