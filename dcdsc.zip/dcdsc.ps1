﻿Configuration ITSwitchDC {

    # this module contains the resources we're using.
    Import-DscResource -ModuleName PsDesiredStateConfiguration

    # installing to localhost target
    Node 'localhost' {

     @('AD-Domain-Services', 'DNS', 'GPMC', 'RSAT-AD-Tools', 'RSAT-DNS-Server').ForEach({
             WindowsFeature $_
             {
                Name = $_
                Ensure = 'Present'
            }
         } 
      )
   }
}

ITSwitchDC

